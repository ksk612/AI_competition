import pandas as pd
import geopandas as gpd
from shapely.geometry import LineString, Polygon

# 1. AIS 데이터 불러오기
df = pd.read_csv('/home/elicer/new/20240701_ver4.csv')

# 2. 해저케이블 GeoJSON 불러오기 + geometry 정리
sea_cable = gpd.read_file('/home/elicer/new/jsons/Sea_cable_lv1_poly.geojson')
sea_cable = sea_cable.explode(index_parts=False, ignore_index=True)  # 멀티폴리곤 분해
sea_cable['geometry'] = sea_cable['geometry'].buffer(0)  # 유효하지 않은 geometry 수정
sea_cable_union = sea_cable.unary_union  # 전체 해저케이블 보호구역 영역 합침

# 3. AIS 항적을 선형(LineString)으로 생성
df['geometry'] = df.apply(
    lambda row: LineString([(row['min_lon'], row['min_lat']), (row['max_lon'], row['max_lat'])]),
    axis=1
)
gdf = gpd.GeoDataFrame(df, geometry='geometry', crs='EPSG:4326')

# 4. 항적 경로와 해저케이블 보호구역의 교차된 길이 계산
def compute_intersection_length(row, sea_cable_union):
    traj_line = LineString([(row['min_lon'], row['min_lat']), (row['max_lon'], row['max_lat'])])
    
    # 교차된 부분 계산
    intersection = traj_line.intersection(sea_cable_union)
    
    # 교차된 길이 계산
    intersection_length = intersection.length if intersection.is_valid else 0
    
    return intersection_length

# 5. 교차된 길이 값을 새로운 feature로 추가
df['sea_cable_intersection_length'] = df.apply(lambda row: compute_intersection_length(row, sea_cable_union), axis=1)

# 6. 결과 저장
df.drop(columns='geometry').to_csv('/home/elicer/new/20240701_ver5.csv', index=False)
