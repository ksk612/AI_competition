import pandas as pd
import geopandas as gpd
from shapely.geometry import box

# 1. AIS 데이터 불러오기
df = pd.read_csv('/home/elicer/ais/final/20240701.csv')

# 2. 정박지 GeoJSON 불러오기 + geometry 정리
anchor_zone = gpd.read_file('/home/elicer/new/jsons/Near_Sea.geojson')
anchor_zone = anchor_zone.explode(index_parts=False, ignore_index=True)
anchor_zone['geometry'] = anchor_zone['geometry'].buffer(0)
anchor_union = anchor_zone.unary_union

# ✅ 3. 항적 사각형을 약간 확장해서 생성
df['geometry'] = df.apply(
    lambda row: box(row['min_lon'], row['min_lat'], row['max_lon'], row['max_lat']),
    axis=1
)
gdf = gpd.GeoDataFrame(df, geometry='geometry', crs='EPSG:4326')

# 4. 겹치는지 확인 (공간 교차)
gdf['in_anchor_zone'] = gdf.geometry.intersects(anchor_union)

# 5. 저장 또는 결과 확인
gdf.drop(columns='geometry').to_csv('/home/elicer/new/20240701_ver4.csv', index=False)
