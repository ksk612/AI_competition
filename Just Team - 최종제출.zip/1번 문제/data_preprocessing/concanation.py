import os
import pandas as pd

# 1. 폴더 경로 지정
folder_path = "/home/elicer/ais/dataset"  # 예: "./data" 또는 "/home/user/ais_data"

# 2. 해당 폴더 내 모든 CSV 파일 리스트
csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]

# 3. CSV들을 하나의 리스트로 불러오기
df_list = [pd.read_csv(os.path.join(folder_path, file)) for file in csv_files]

# 4. 하나로 concat
merged_df = pd.concat(df_list, ignore_index=True)

# 5. 결과 확인
print(merged_df.shape)
print(merged_df.head())

# 6. (선택) 합친 파일 저장
merged_df.to_csv("dataset.csv", index=False)
