import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
from xgboost import XGBClassifier
from glob import glob
from datetime import datetime, timedelta
import pickle
import os

SEED = 1128

# 현재 시각
now_kst = datetime.utcnow() + timedelta(hours=9)
now_str = now_kst.strftime("%H%M")

# 1. 데이터 불러오기
# csv_files = glob("/home/elicer/ais/dataset/*.csv")
# df = pd.concat([pd.read_csv(file) for file in csv_files], ignore_index=True)

df = pd.read_csv("/home/elicer/new/dataset_ver5.csv")


# 2. 피처와 타겟 분리
y = df['result']
X = df.drop(columns=['result'])

# 3. 라벨 인코딩
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# 4. 학습/검증 분할
X_train, X_val, y_train, y_val = train_test_split(
    X, y_encoded, test_size=0.2, stratify=y_encoded, random_state=SEED
)

# 5. 모델 정의
model = XGBClassifier(
    use_label_encoder=False,
    eval_metric='logloss',
    learning_rate=0.1,
    max_depth=10,
    early_stopping_rounds=50,
    n_estimators=2000,  # early stopping 사용하므로 충분히 크게
    subsample = 0.8
    # tree_method='gpu_hist' ############야ㅑㅑ!!!!!###################
)
print(type(model))

# 6. 학습 with early stopping
model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    verbose=True
)


model_path = "/home/elicer/ais/final/best_model_xgb.pkl"
with open(model_path, "wb") as f:
    pickle.dump(model, f)


# 2. 예측 대상 데이터 로드
predict_df = pd.read_csv("/home/elicer/new/20240701_ver5.csv")

# 3. MMSI 따로 저장하고, result 컬럼은 제외
mmsi = predict_df['MMSI']
X_pred = predict_df.drop(columns=['result']) if 'result' in predict_df.columns else predict_df.copy()

# 4. 예측
y_pred = model.predict(X_pred)

# 5. 예측 결과를 TRUE / FALSE로 변환
result_str = ['TRUE' if val == 1 else 'FALSE' for val in y_pred]

# 6. MMSI와 예측 결과 결합
output_df = pd.DataFrame({
    'MMSI': mmsi,
    'result': result_str
})

base_path = "/home/elicer/ais/final/xg_20240701.csv"
dirname, filename = os.path.split(base_path)
name, ext = os.path.splitext(filename)

new_filename = f"{name}({SEED}){ext}"
output_path = os.path.join(dirname, new_filename)


output_df.to_csv(output_path, index=False)
print(f"✅ 예측 결과 저장 완료: {output_path}")


######################
# 🔍 에러 분석 (검증 데이터셋 기준으로 틀린 샘플 저장)
# y_pred = model.predict(X_val)
# val_df = X_val.copy()
# val_df['true_result'] = ['TRUE' if y == 1 else 'FALSE' for y in y_val]
# val_df['predicted_result'] = ['TRUE' if y == 1 else 'FALSE' for y in y_pred]

# error_mask = y_pred != y_val
# error_df = val_df[error_mask].copy()

# # 저장 경로 지정
# error_output_path = os.path.join(dirname, f"val_errors({now_str}){ext}")
# error_df.to_csv(error_output_path, index=False)
# print(f"❗ Validation 틀린 예측 저장 완료: {error_output_path}")
# # ######################


# importances = model.get_booster().get_score(importance_type='weight')

# # 중요도 높은 순으로 정렬
# importance_df = pd.DataFrame({
#     'Feature': list(importances.keys()),
#     'Importance': list(importances.values())
# }).sort_values(by='Importance', ascending=False)

# print("\n📊 Feature Importances (All Features):")
# for i, row in importance_df.iterrows():
#     print(f"{row['Feature']:<30} : {row['Importance']:.6f}")