import pandas as pd
import pickle
from datetime import datetime, timedelta
import os
import numpy as np

# 현재 시각 (KST)
now_kst = datetime.utcnow() + timedelta(hours=9)
now_str = now_kst.strftime("%H%M")

# 📂 모델 불러오기
model_paths = [
    "/home/elicer/ais/final/best_model_catboost.pkl",
    "/home/elicer/ais/final/best_model_lgbm.pkl",
    "/home/elicer/ais/final/best_model_xgb.pkl"
]

models = []
for path in model_paths:
    with open(path, "rb") as f:
        models.append(pickle.load(f))

# 📄 예측 대상 데이터 불러오기
predict_df = pd.read_csv("/home/elicer/new/20240701_ver5.csv")
mmsi = predict_df['MMSI']
X_pred = predict_df.drop(columns=['result']) if 'result' in predict_df.columns else predict_df.copy()

# 🎯 소프트보팅 예측 (확률 평균)
proba_sum = np.zeros((len(X_pred), 2))  # (n_samples, n_classes)
for model in models:
    proba_sum += model.predict_proba(X_pred)

avg_proba = proba_sum / len(models)
y_pred = np.argmax(avg_proba, axis=1)  # 클래스 예측

# 📝 결과 TRUE/FALSE 변환
result_str = ['TRUE' if val == 1 else 'FALSE' for val in y_pred]

# 📤 결과 저장
output_df = pd.DataFrame({
    'MMSI': mmsi,
    'result': result_str
})

# 파일명 구성 및 저장
base_path = "/home/elicer/ais/final/20240701.csv"
dirname, filename = os.path.split(base_path)
name, ext = os.path.splitext(filename)
new_filename = f"{name}_ensemble({now_str}){ext}"
output_path = os.path.join(dirname, new_filename)


output_df.to_csv(output_path, index=False)
print(f"✅ 앙상블 예측 결과 저장 완료: {output_path}")

# 개별 모델 예측 비교
for i, model in enumerate(models):
    preds = model.predict(X_pred)
    match = np.sum(preds == y_pred)
    print(f"모델 {i+1}과 앙상블 결과 일치 비율: {match / len(y_pred):.4f}")
