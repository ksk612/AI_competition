import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
from catboost import CatBoostClassifier
from glob import glob
from datetime import datetime, timedelta
import pickle
import os

SEED = 1128


# 현재 시각
now_kst = datetime.utcnow() + timedelta(hours=9)
now_str = now_kst.strftime("%H%M")

# 1. 데이터 불러오기
# csv_files = glob("/home/elicer/ais/dataset/*.csv")
# df = pd.concat([pd.read_csv(file) for file in csv_files], ignore_index=True)

df = pd.read_csv("/home/elicer/new/dataset_ver5.csv")


# 2. 피처와 타겟 분리
y = df['result']
X = df.drop(columns=['result'])

# 3. 라벨 인코딩
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# 4. 학습/검증 분할
X_train, X_val, y_train, y_val = train_test_split(
    X, y_encoded, test_size=0.2, stratify=y_encoded, random_state=SEED
)

# 5. 모델 정의
model = CatBoostClassifier(
    learning_rate=0.1,
    depth=10,
    bootstrap_type='Bernoulli',
    iterations=3000,
    od_type='Iter',
    od_wait=50,
    verbose=100,
    task_type='GPU',
    subsample=0.8
)


# 6. 학습
model.fit(
    X_train, y_train,
    eval_set=(X_val, y_val),
    use_best_model=True
)

# 7. 저장
model_path = "/home/elicer/ais/final/best_model_catboost.pkl"
with open(model_path, "wb") as f:
    pickle.dump(model, f)

# 8. 모델 로드
with open(model_path, "rb") as f:
    model = pickle.load(f)

# 9. 예측 대상 데이터 로드
predict_df = pd.read_csv("/home/elicer/new/20240701_ver5.csv")

# 10. MMSI 따로 저장하고, result 컬럼은 제외
mmsi = predict_df['MMSI']
X_pred = predict_df.drop(columns=['result']) if 'result' in predict_df.columns else predict_df.copy()

# 11. 예측
y_pred = model.predict(X_pred)

# 12. 예측 결과를 TRUE / FALSE로 변환
result_str = ['TRUE' if int(val) == 1 else 'FALSE' for val in y_pred]

# 13. MMSI와 예측 결과 결합
output_df = pd.DataFrame({
    'MMSI': mmsi,
    'result': result_str
})

# 저장 경로 처리용
base_path = "/home/elicer/ais/final/cat_20240701.csv"
dirname, filename = os.path.split(base_path)
name, ext = os.path.splitext(filename)


new_filename = f"{name}({SEED}){ext}"
output_path = os.path.join(dirname, new_filename)


output_df.to_csv(output_path, index=False)
print(f"✅ 예측 결과 저장 완료: {output_path}")


######################
# # 🔍 에러 분석 (검증 데이터셋 기준으로 틀린 샘플 저장)
# y_pred = model.predict(X_val)
# val_df = X_val.copy()
# val_df['true_result'] = ['TRUE' if y == 1 else 'FALSE' for y in y_val]
# val_df['predicted_result'] = ['TRUE' if y == 1 else 'FALSE' for y in y_pred]

# error_mask = y_pred != y_val
# error_df = val_df[error_mask].copy()

# # 저장 경로 지정
# error_output_path = os.path.join(dirname, f"val_errors({now_str}){ext}")
# error_df.to_csv(error_output_path, index=False)
# print(f"❗ Validation 틀린 예측 저장 완료: {error_output_path}")
# ######################