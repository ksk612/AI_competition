#!/usr/bin/env python3

import pandas as pd
import numpy as np
import os
import random
from catboost import CatBoostClassifier

RANDOM_SEED = 42

def set_all_seeds(seed=RANDOM_SEED):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    try:
        import pandas as pd
        pd.core.common.random_state(seed)
    except:
        pass

set_all_seeds(RANDOM_SEED)

def extract_ais_features(file_path, mmsi):
    try:
        df = pd.read_csv(file_path)
        
        if len(df) == 0:
            return None
            
        features = {
            'mmsi': mmsi,
            'track_length': len(df),
            'lat_mean': df['latitude'].mean(),
            'lat_std': df['latitude'].std(),
            'lat_min': df['latitude'].min(),
            'lat_max': df['latitude'].max(),
            'lat_range': df['latitude'].max() - df['latitude'].min(),
            'lat_median': df['latitude'].median(),
            'lat_q25': df['latitude'].quantile(0.25),
            'lat_q75': df['latitude'].quantile(0.75),
            'lon_mean': df['longitude'].mean(),
            'lon_std': df['longitude'].std(),
            'lon_min': df['longitude'].min(),
            'lon_max': df['longitude'].max(),
            'lon_range': df['longitude'].max() - df['longitude'].min(),
            'lon_median': df['longitude'].median(),
            'lon_q25': df['longitude'].quantile(0.25),
            'lon_q75': df['longitude'].quantile(0.75),
            'sog_mean': df['sog'].mean(),
            'sog_std': df['sog'].std(),
            'sog_min': df['sog'].min(),
            'sog_max': df['sog'].max(),
            'sog_median': df['sog'].median(),
            'sog_zero_ratio': (df['sog'] == 0).mean(),
            'sog_low_ratio': (df['sog'] < 1).mean(),
            'sog_high_ratio': (df['sog'] > 15).mean(),
            'cog_mean': df['cog'].mean(),
            'cog_std': df['cog'].std(),
            'cog_changes': np.abs(np.diff(df['cog'])).mean() if len(df) > 1 else 0,
            'cog_sudden_changes': (np.abs(np.diff(df['cog'])) > 90).sum() if len(df) > 1 else 0,
        }
        
        features.update({
            'in_nk_zone': int(features['lat_mean'] >= 38.0 and 124.0 <= features['lon_mean'] <= 130.0),
            'near_nk_border': int(37.0 <= features['lat_mean'] <= 39.0 and 123.0 <= features['lon_mean'] <= 131.0),
            'lat_above_38': int(features['lat_mean'] >= 38.0),
            'lat_above_39': int(features['lat_mean'] >= 39.0),
            'distance_from_nk_center': np.sqrt((features['lat_mean'] - 39.0)**2 + (features['lon_mean'] - 127.0)**2),
            'lat_38_plus_nk_zone': int(features['lat_mean'] >= 38.0 and 124.0 <= features['lon_mean'] <= 130.0),
            'lat_38_plus_nk_core': int(features['lat_mean'] >= 38.0 and 125.0 <= features['lon_mean'] <= 129.0),
            'lat_38_plus_west_coast': int(features['lat_mean'] >= 38.0 and 124.0 <= features['lon_mean'] <= 126.0),
            'lat_38_plus_east_coast': int(features['lat_mean'] >= 38.0 and 128.0 <= features['lon_mean'] <= 130.0),
            'lat_39_plus_nk_zone': int(features['lat_mean'] >= 39.0 and 124.0 <= features['lon_mean'] <= 130.0),
            'lat_40_plus_nk_zone': int(features['lat_mean'] >= 40.0 and 124.0 <= features['lon_mean'] <= 130.0),
            'nk_core_zone': int(38.5 <= features['lat_mean'] <= 42.0 and 124.5 <= features['lon_mean'] <= 129.5),
            'nk_extended_zone': int(37.5 <= features['lat_mean'] <= 43.0 and 123.0 <= features['lon_mean'] <= 131.0),
            'nk_fishing_zone': int(38.0 <= features['lat_mean'] <= 40.0 and 124.0 <= features['lon_mean'] <= 127.0),
            'nk_military_zone': int(39.0 <= features['lat_mean'] <= 41.0 and 127.0 <= features['lon_mean'] <= 129.0),
            'yellow_sea_nk': int(features['lat_mean'] >= 38.0 and 124.0 <= features['lon_mean'] <= 126.5),
            'east_sea_nk': int(features['lat_mean'] >= 38.0 and 127.5 <= features['lon_mean'] <= 130.0),
            'dmz_adjacent': int(37.8 <= features['lat_mean'] <= 38.5 and 125.0 <= features['lon_mean'] <= 128.0),
            'korean_west_coast': int(features['lat_mean'] <= 38.0 and 124.0 <= features['lon_mean'] <= 126.5),
            'korean_south_coast': int(features['lat_mean'] <= 36.0 and 126.0 <= features['lon_mean'] <= 130.0),
            'korean_east_coast': int(features['lat_mean'] <= 38.0 and 128.0 <= features['lon_mean'] <= 132.0),
            'incheon_area': int(37.0 <= features['lat_mean'] <= 38.0 and 124.0 <= features['lon_mean'] <= 126.0),
            'busan_area': int(34.5 <= features['lat_mean'] <= 36.0 and 128.0 <= features['lon_mean'] <= 130.0),
            'clearly_korean_waters': int(
                (features['lat_mean'] <= 37.5) or
                (features['lat_mean'] <= 38.0 and features['lon_mean'] <= 126.0) or
                (features['lat_mean'] <= 38.0 and features['lon_mean'] >= 128.5)
            ),
            'ambiguous_border_area': int(
                37.5 <= features['lat_mean'] <= 38.5 and 126.0 <= features['lon_mean'] <= 128.5
            ),
            'lat_min_above_38': int(features['lat_min'] >= 38.0),
            'lat_max_above_38': int(features['lat_max'] >= 38.0),
            'lat_min_above_39': int(features['lat_min'] >= 39.0),
            'lat_max_above_39': int(features['lat_max'] >= 39.0),
            'lat_min_above_40': int(features['lat_min'] >= 40.0),
            'lat_max_above_40': int(features['lat_max'] >= 40.0),
            'lon_min_in_nk': int(124.0 <= features['lon_min'] <= 130.0),
            'lon_max_in_nk': int(124.0 <= features['lon_max'] <= 130.0),
            'lon_entirely_in_nk': int(124.0 <= features['lon_min'] and features['lon_max'] <= 130.0),
            'ever_in_nk_core': int(((df['latitude'] >= 38.5) & (df['latitude'] <= 42.0) & 
                                   (df['longitude'] >= 124.5) & (df['longitude'] <= 129.5)).any()),
            'ever_in_nk_extended': int(((df['latitude'] >= 37.5) & (df['latitude'] <= 43.0) & 
                                       (df['longitude'] >= 123.0) & (df['longitude'] <= 131.0)).any()),
            'ever_above_38': int((df['latitude'] >= 38.0).any()),
            'ever_above_39': int((df['latitude'] >= 39.0).any()),
            'ever_above_40': int((df['latitude'] >= 40.0).any()),
            'ever_in_yellow_sea_nk': int(((df['latitude'] >= 38.0) & 
                                         (df['longitude'] >= 124.0) & (df['longitude'] <= 126.5)).any()),
            'ever_in_east_sea_nk': int(((df['latitude'] >= 38.0) & 
                                       (df['longitude'] >= 127.5) & (df['longitude'] <= 130.0)).any()),
            'ever_in_dmz_adjacent': int(((df['latitude'] >= 37.8) & (df['latitude'] <= 38.5) & 
                                        (df['longitude'] >= 125.0) & (df['longitude'] <= 128.0)).any()),
            'entirely_above_38': int(features['lat_min'] >= 38.0),
            'entirely_above_39': int(features['lat_min'] >= 39.0),
            'crosses_38_line': int(features['lat_min'] < 38.0 and features['lat_max'] >= 38.0),
            'crosses_39_line': int(features['lat_min'] < 39.0 and features['lat_max'] >= 39.0),
            'crosses_nk_border': int(features['lon_min'] < 124.0 and features['lon_max'] >= 124.0),
        })
        
        features.update({
            'erratic_movement': features['cog_sudden_changes'] / max(features['track_length'], 1),
            'speed_inconsistency': features['sog_std'] / max(features['sog_mean'], 0.1),
            'stationary_periods': features['sog_zero_ratio'],
            'movement_efficiency': features['lat_range'] + features['lon_range'],
        })
        
        track_len = features['track_length']
        features.update({
            'is_very_short_track': int(track_len <= 5),
            'is_short_track': int(6 <= track_len <= 20),
            'is_medium_track': int(21 <= track_len <= 100),
            'is_long_track': int(101 <= track_len <= 500),
            'is_very_long_track': int(track_len > 500),
            'short_track_suspicion': max(0, (30 - track_len) / 30) if track_len <= 30 else 0,
            'track_length_log': np.log(track_len + 1),
            'track_length_inverse': 1 / (track_len + 1),
            'short_track_in_nk_zone': int(track_len <= 20 and features['in_nk_zone']),
            'short_track_high_speed': int(track_len <= 20 and features['sog_mean'] > 20),
            'short_track_erratic': int(track_len <= 20 and features['cog_sudden_changes'] > 0),
            'suspicious_track_length': int(20 <= track_len <= 50),
            'moderate_speed_pattern': int(7.0 <= features['sog_mean'] <= 12.0),
            'low_direction_changes': int(features['cog_sudden_changes'] <= 2),
            'consistent_speed': int(features['sog_std'] <= 1.0),
            'distant_nk_activity': int(
                (features['lat_mean'] >= 35.0) and
                (features['lon_mean'] >= 128.0) and
                (track_len >= 20) and
                (7.0 <= features['sog_mean'] <= 12.0)
            ),
            'east_sea_operation': int(
                (features['lon_mean'] >= 129.0) and
                (features['lat_mean'] >= 35.0) and
                (features['sog_mean'] >= 8.0)
            ),
            'long_range_mission': int(
                (features['distance_from_nk_center'] >= 4.0) and
                (track_len >= 20) and
                (features['sog_std'] <= 2.0)
            ),
            'special_mission_pattern': int(
                (features['lat_mean'] >= 35.0) and
                (features['lon_mean'] >= 129.0) and
                (20 <= track_len <= 50) and
                (8.0 <= features['sog_mean'] <= 10.0) and
                (features['cog_sudden_changes'] <= 3)
            ),
            'missing_data_suspicion': int(
                (features['sog_std'] != features['sog_std']) or
                (features['cog_std'] != features['cog_std'])
            ),
            'data_quality_score': (
                1.0 if not pd.isna(features['sog_std']) else 0.5
            )
        })
        
        features.update({
            'anomaly_score': (
                features['in_nk_zone'] * 0.3 +
                features['erratic_movement'] * 0.2 +
                features['stationary_periods'] * 0.2 +
                features['speed_inconsistency'] * 0.15 +
                (1 / max(features['track_length'], 1)) * 0.15
            ),
            'enhanced_anomaly_score': (
                features['in_nk_zone'] * 0.25 +
                features['erratic_movement'] * 0.15 +
                features['stationary_periods'] * 0.15 +
                features['speed_inconsistency'] * 0.1 +
                features['short_track_suspicion'] * 0.2 +
                features['short_track_in_nk_zone'] * 0.15
            ),
            'comprehensive_anomaly_score': (
                features['ever_in_nk_core'] * 0.15 +
                features['ever_in_nk_extended'] * 0.1 +
                features['entirely_above_38'] * 0.05 +
                features['ever_above_38'] * 0.08 +
                features['ever_above_39'] * 0.1 +
                features['ever_above_40'] * 0.07 +
                features['erratic_movement'] * 0.1 +
                features['stationary_periods'] * 0.1 +
                features['short_track_suspicion'] * 0.1 +
                features['crosses_38_line'] * 0.05 +
                features['yellow_sea_nk'] * 0.05 +
                features['east_sea_nk'] * 0.05 +
                features['clearly_korean_waters'] * (-0.2) +
                features['korean_south_coast'] * (-0.15) +
                features['incheon_area'] * (-0.1) +
                features['busan_area'] * (-0.1)
            ),
            'extremes_based_score': (
                features['lat_min_above_38'] * 0.2 +
                features['lat_min_above_39'] * 0.25 +
                features['lon_entirely_in_nk'] * 0.3 +
                features['entirely_above_38'] * 0.25 +
                features['clearly_korean_waters'] * (-0.3)
            ),
            'geographic_confidence_score': (
                features['nk_core_zone'] * 0.4 +
                features['lat_39_plus_nk_zone'] * 0.3 +
                features['lat_40_plus_nk_zone'] * 0.2 +
                features['clearly_korean_waters'] * (-0.5) +
                features['ambiguous_border_area'] * (-0.1)
            ),
        })
        
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
            time_diffs = df['timestamp'].diff().dt.total_seconds().dropna()
            if len(time_diffs) > 0:
                features.update({
                    'avg_time_interval': time_diffs.mean(),
                    'time_interval_std': time_diffs.std(),
                    'irregular_intervals': (time_diffs > time_diffs.mean() + 2*time_diffs.std()).sum(),
                })
            else:
                features.update({
                    'avg_time_interval': 0,
                    'time_interval_std': 0,
                    'irregular_intervals': 0,
                })
        else:
            features.update({
                'avg_time_interval': 0,
                'time_interval_std': 0,
                'irregular_intervals': 0,
            })
        
        return features
        
    except Exception as e:
        return None

def create_enhanced_features_for_submission(file_path, mmsi):
    features = extract_ais_features(file_path, mmsi)
    df = pd.read_csv(file_path)
    
    enhanced_features = {}
    
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        unique_dates = df['timestamp'].dt.date.nunique()
        date_span = (df['timestamp'].max() - df['timestamp'].min()).days
        enhanced_features.update({
            'multi_day_activity': int(unique_dates > 1),
            'activity_date_span': date_span,
            'activity_density': len(df) / max(date_span, 1),
        })
    else:
        enhanced_features.update({
            'multi_day_activity': 0,
            'activity_date_span': 0,
            'activity_density': 0,
        })
    
    near_38_ratio = ((df['latitude'] >= 37.5) & (df['latitude'] <= 38.5)).mean()
    above_38_ratio = (df['latitude'] > 38.0).mean()
    crosses_38_multiple = int(features['crosses_38_line'] and above_38_ratio > 0.1)
    
    enhanced_features.update({
        'near_38_line_ratio': near_38_ratio,
        'above_38_ratio': above_38_ratio,
        'crosses_38_multiple_times': crosses_38_multiple,
        'border_activity_pattern': int(near_38_ratio > 0.3),
    })
    
    japan_sea_activity = ((df['latitude'] >= 33.0) & (df['latitude'] <= 37.0) & 
                         (df['longitude'] >= 128.0) & (df['longitude'] <= 132.0)).mean()
    enhanced_features.update({
        'japan_sea_activity_ratio': japan_sea_activity,
        'operates_in_japan_waters': int(japan_sea_activity > 0.5),
    })
    
    lat_range = features['lat_range']
    lon_range = features['lon_range']
    total_range = lat_range + lon_range
    enhanced_features.update({
        'long_range_operation': int(total_range > 4.0),
        'north_south_movement': int(lat_range > 2.0),
        'east_west_movement': int(lon_range > 2.0),
    })
    
    if 'sog' in df.columns and len(df) > 1:
        speed_consistency = 1.0 / (features['sog_std'] + 0.1)
        commercial_speed_pattern = int(7.0 <= features['sog_mean'] <= 12.0 and features['sog_std'] < 2.0)
    else:
        speed_consistency = 0
        commercial_speed_pattern = 0
    
    enhanced_features.update({
        'speed_consistency_score': speed_consistency,
        'commercial_speed_pattern': commercial_speed_pattern,
    })
    
    hidden_nk_pattern = int(
        enhanced_features['crosses_38_multiple_times'] and
        enhanced_features['long_range_operation'] and
        enhanced_features['multi_day_activity'] and
        enhanced_features['commercial_speed_pattern']
    )
    
    enhanced_features.update({
        'hidden_nk_vessel_pattern': hidden_nk_pattern,
        'sophisticated_operation': int(
            enhanced_features['operates_in_japan_waters'] and
            enhanced_features['border_activity_pattern'] and
            enhanced_features['speed_consistency_score'] > 2.0
        )
    })
    
    enhanced_features.update({
        'distant_nk_activity_enhanced': int(
            (features['lat_mean'] >= 33.0) and
            (features['lon_mean'] >= 128.0) and
            (features['track_length'] >= 20) and
            (7.0 <= features['sog_mean'] <= 12.0)
        ),
        'border_crossing_activity': int(
            features['crosses_38_line'] and
            enhanced_features['above_38_ratio'] > 0.05
        ),
        'sophisticated_disguise': int(
            enhanced_features['commercial_speed_pattern'] and
            enhanced_features['long_range_operation'] and
            not features['in_nk_zone']
        ),
        'persistent_activity': int(
            enhanced_features['activity_date_span'] > 30 and
            enhanced_features['activity_density'] < 5
        )
    })
    
    features.update(enhanced_features)
    
    return features

def load_training_features(data_dir, alternative_data_dir, train_label_file):
    labels_df = pd.read_csv(train_label_file)
    all_features = []
    
    for idx, row in labels_df.iterrows():
        mmsi = row['Anonymized_MMSI']
        label = 1 if row['label'] == True else 0
        
        file_path = os.path.join(data_dir, f"{mmsi}.csv")
        features = None
        
        if os.path.exists(file_path):
            features = create_enhanced_features_for_submission(file_path, mmsi)
        
        if features is None and alternative_data_dir:
            alt_file_path = os.path.join(alternative_data_dir, f"{mmsi}.csv")
            if os.path.exists(alt_file_path):
                features = create_enhanced_features_for_submission(alt_file_path, mmsi)
        
        if features is not None:
            features['label'] = label
            all_features.append(features)
    
    return pd.DataFrame(all_features)

def load_test_features(data_dir, alternative_data_dir, test_file):
    test_df = pd.read_csv(test_file)
    all_features = []
    
    for idx, row in test_df.iterrows():
        mmsi = row['Anonymized_MMSI']
        
        file_path = os.path.join(data_dir, f"{mmsi}.csv")
        features = None
        
        if os.path.exists(file_path):
            features = create_enhanced_features_for_submission(file_path, mmsi)
        
        if features is None and alternative_data_dir:
            alt_file_path = os.path.join(alternative_data_dir, f"{mmsi}.csv")
            if os.path.exists(alt_file_path):
                features = create_enhanced_features_for_submission(alt_file_path, mmsi)
        
        if features is not None:
            all_features.append(features)
    
    return pd.DataFrame(all_features)

def train_final_model():
    set_all_seeds(RANDOM_SEED)
    
    data_dir = "../mmsi_tracks/processed_mmsi_tracks"
    alternative_data_dir = "../mmsi_tracks/mmsi_tracks"
    train_label_file = "../mmsi_tracks/train_label_filtered.csv"
    test_file = "../mmsi_tracks/test_filtered.csv"
    
    train_features_df = load_training_features(data_dir, alternative_data_dir, train_label_file)
    test_features_df = load_test_features(data_dir, alternative_data_dir, test_file)
    
    feature_columns = [col for col in train_features_df.columns if col not in ['mmsi', 'label']]
    X_train = train_features_df[feature_columns].fillna(0)
    y_train = train_features_df['label']
    
    for feature in feature_columns:
        if feature not in test_features_df.columns:
            test_features_df[feature] = 0
    
    X_test = test_features_df[feature_columns].fillna(0)
    
    model = CatBoostClassifier(
        iterations=500,
        learning_rate=0.05,
        depth=8,
        l2_leaf_reg=3,
        bootstrap_type='Bernoulli',
        subsample=0.8,
        random_seed=RANDOM_SEED,
        verbose=0,
        eval_metric='F1',
        class_weights=[1, 4],
        early_stopping_rounds=50
    )
    
    model.fit(X_train, y_train)

    print("Training Finished")
    
    test_proba = model.predict_proba(X_test)[:, 1]
    optimal_threshold = 0.72
    test_predictions = (test_proba >= optimal_threshold).astype(int)
    
    return model, test_predictions, test_proba, test_features_df

def create_final_submission():
    model, predictions, probabilities, test_features_df = train_final_model()
    
    submission_df = pd.DataFrame({
        'Anonymized_MMSI': test_features_df['mmsi'],
        'label': pd.Series(predictions).map({0: 'FALSE', 1: 'TRUE'})
    })
    submission_df.columns = ['MMSI', 'result']
    submission_df.to_csv("submission.csv", index=False)
    
    return submission_df

if __name__ == "__main__":
    submission_df = create_final_submission() 