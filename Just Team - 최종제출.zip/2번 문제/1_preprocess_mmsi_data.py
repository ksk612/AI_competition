"""
MMSI 궤적 데이터 전처리 스크립트

대용량 AIS 궤적 데이터를 효율적으로 처리하기 위해:
1. 하루 단위로 데이터를 그룹화
2. 일별 평균 좌표, 속도, 방향 계산
3. 멀티프로세싱으로 빠른 처리
4. 메모리 효율적인 샘플링
"""

import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import logging
from datetime import datetime, timedelta
import multiprocessing as mp
from functools import partial
from tqdm import tqdm
import warnings
import argparse

warnings.filterwarnings('ignore')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def process_single_mmsi_file(mmsi_file_path: Path, output_dir: Path, sampling_strategy: str = 'daily_avg') -> Dict:
    """
    단일 MMSI 파일을 처리하여 샘플링된 데이터 생성
    
    Args:
        mmsi_file_path: MMSI CSV 파일 경로
        output_dir: 출력 디렉토리
        sampling_strategy: 샘플링 전략 ('daily_avg', 'hourly_avg', 'random')
    
    Returns:
        처리 결과 딕셔너리
    """
    try:
        mmsi = mmsi_file_path.stem
        
        # 데이터 로딩
        df = pd.read_csv(mmsi_file_path)
        
        if len(df) == 0:
            return {'mmsi': mmsi, 'status': 'empty', 'original_size': 0, 'processed_size': 0}
        
        original_size = len(df)
        
        # timestamp 컬럼을 datetime으로 변환
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        # 샘플링 전략에 따른 처리
        if sampling_strategy == 'daily_avg':
            processed_df = daily_average_sampling(df)
        elif sampling_strategy == 'hourly_avg':
            processed_df = hourly_average_sampling(df)
        elif sampling_strategy == 'random':
            processed_df = random_sampling(df, sample_ratio=0.1)
        else:
            processed_df = daily_average_sampling(df)  # 기본값
        
        processed_size = len(processed_df)
        
        # 결과 저장
        output_file = output_dir / f"{mmsi}.csv"
        processed_df.to_csv(output_file, index=False)
        
        return {
            'mmsi': mmsi,
            'status': 'success',
            'original_size': original_size,
            'processed_size': processed_size,
            'compression_ratio': processed_size / original_size if original_size > 0 else 0
        }
        
    except Exception as e:
        return {
            'mmsi': mmsi_file_path.stem,
            'status': 'error',
            'error': str(e),
            'original_size': 0,
            'processed_size': 0
        }


def daily_average_sampling(df: pd.DataFrame) -> pd.DataFrame:
    """
    하루 단위로 평균값을 계산하여 샘플링
    
    Args:
        df: 원본 궤적 데이터
    
    Returns:
        일별 평균 데이터
    """
    # 날짜별로 그룹화
    df['date'] = df['timestamp'].dt.date
    
    # 일별 통계 계산
    daily_stats = df.groupby('date').agg({
        'latitude': ['mean', 'std', 'min', 'max', 'count'],
        'longitude': ['mean', 'std', 'min', 'max'],
        'sog': ['mean', 'std', 'min', 'max'],
        'cog': ['mean', 'std', 'min', 'max'],
        'timestamp': ['min', 'max']  # 하루의 시작과 끝 시간
    }).reset_index()
    
    # 컬럼명 정리
    daily_stats.columns = [
        'date',
        'latitude', 'latitude_std', 'latitude_min', 'latitude_max', 'point_count',
        'longitude', 'longitude_std', 'longitude_min', 'longitude_max',
        'sog', 'sog_std', 'sog_min', 'sog_max',
        'cog', 'cog_std', 'cog_min', 'cog_max',
        'timestamp_start', 'timestamp_end'
    ]
    
    # 대표 timestamp는 하루의 중간 시점으로 설정
    daily_stats['timestamp'] = daily_stats['timestamp_start'] + (
        daily_stats['timestamp_end'] - daily_stats['timestamp_start']
    ) / 2
    
    # 필요한 컬럼만 선택 (기존 형식 유지)
    result_df = daily_stats[[
        'timestamp', 'sog', 'cog', 'latitude', 'longitude',
        'latitude_std', 'longitude_std', 'sog_std', 'cog_std',
        'point_count'
    ]].copy()
    
    return result_df


def hourly_average_sampling(df: pd.DataFrame) -> pd.DataFrame:
    """
    시간 단위로 평균값을 계산하여 샘플링
    
    Args:
        df: 원본 궤적 데이터
    
    Returns:
        시간별 평균 데이터
    """
    # 시간별로 그룹화 (날짜 + 시간)
    df['hour'] = df['timestamp'].dt.floor('H')
    
    # 시간별 통계 계산
    hourly_stats = df.groupby('hour').agg({
        'latitude': ['mean', 'std', 'count'],
        'longitude': ['mean', 'std'],
        'sog': ['mean', 'std'],
        'cog': ['mean', 'std']
    }).reset_index()
    
    # 컬럼명 정리
    hourly_stats.columns = [
        'timestamp',
        'latitude', 'latitude_std', 'point_count',
        'longitude', 'longitude_std',
        'sog', 'sog_std',
        'cog', 'cog_std'
    ]
    
    return hourly_stats


def random_sampling(df: pd.DataFrame, sample_ratio: float = 0.1) -> pd.DataFrame:
    """
    랜덤 샘플링
    
    Args:
        df: 원본 궤적 데이터
        sample_ratio: 샘플링 비율
    
    Returns:
        랜덤 샘플링된 데이터
    """
    sample_size = max(1, int(len(df) * sample_ratio))
    return df.sample(n=sample_size, random_state=42).sort_values('timestamp')


def get_mmsi_files(tracks_dir: Path) -> List[Path]:
    """
    MMSI 궤적 파일 목록 가져오기
    
    Args:
        tracks_dir: 궤적 파일 디렉토리
    
    Returns:
        MMSI 파일 경로 리스트
    """
    mmsi_files = list(tracks_dir.glob("*.csv"))
    logger.info(f"Found {len(mmsi_files)} MMSI files")
    return mmsi_files


def process_mmsi_data_parallel(
    tracks_dir: Path,
    output_dir: Path,
    sampling_strategy: str = 'daily_avg',
    num_processes: int = None,
    max_files: int = None
) -> Dict:
    """
    멀티프로세싱으로 MMSI 데이터 병렬 처리
    
    Args:
        tracks_dir: 원본 궤적 파일 디렉토리
        output_dir: 출력 디렉토리
        sampling_strategy: 샘플링 전략
        num_processes: 프로세스 수 (None이면 CPU 코어 수)
        max_files: 최대 처리 파일 수 (테스트용)
    
    Returns:
        처리 결과 요약
    """
    # 출력 디렉토리 생성
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # MMSI 파일 목록 가져오기
    mmsi_files = get_mmsi_files(tracks_dir)
    
    if max_files:
        mmsi_files = mmsi_files[:max_files]
        logger.info(f"Processing limited to {max_files} files for testing")
    
    if not mmsi_files:
        logger.error("No MMSI files found!")
        return {}
    
    # 프로세스 수 설정
    if num_processes is None:
        num_processes = min(mp.cpu_count(), len(mmsi_files))
    
    logger.info(f"Starting parallel processing with {num_processes} processes")
    logger.info(f"Processing {len(mmsi_files)} files with strategy: {sampling_strategy}")
    
    # 부분 함수 생성 (고정 인자들을 미리 바인딩)
    process_func = partial(
        process_single_mmsi_file,
        output_dir=output_dir,
        sampling_strategy=sampling_strategy
    )
    
    # 멀티프로세싱 실행
    results = []
    with mp.Pool(processes=num_processes) as pool:
        # tqdm으로 진행률 표시
        for result in tqdm(
            pool.imap(process_func, mmsi_files),
            total=len(mmsi_files),
            desc="Processing MMSI files"
        ):
            results.append(result)
    
    # 결과 요약
    summary = analyze_results(results)
    
    return summary


def analyze_results(results: List[Dict]) -> Dict:
    """
    처리 결과 분석 및 요약
    
    Args:
        results: 처리 결과 리스트
    
    Returns:
        요약 통계
    """
    total_files = len(results)
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] == 'error']
    empty = [r for r in results if r['status'] == 'empty']
    
    if successful:
        total_original = sum(r['original_size'] for r in successful)
        total_processed = sum(r['processed_size'] for r in successful)
        avg_compression = np.mean([r['compression_ratio'] for r in successful])
    else:
        total_original = total_processed = avg_compression = 0
    
    summary = {
        'total_files': total_files,
        'successful': len(successful),
        'failed': len(failed),
        'empty': len(empty),
        'success_rate': len(successful) / total_files if total_files > 0 else 0,
        'total_original_points': total_original,
        'total_processed_points': total_processed,
        'average_compression_ratio': avg_compression,
        'data_reduction': 1 - avg_compression if avg_compression > 0 else 0
    }
    
    # 결과 출력
    logger.info("=" * 60)
    logger.info("PROCESSING SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Total files: {summary['total_files']}")
    logger.info(f"Successful: {summary['successful']}")
    logger.info(f"Failed: {summary['failed']}")
    logger.info(f"Empty: {summary['empty']}")
    logger.info(f"Success rate: {summary['success_rate']:.2%}")
    logger.info(f"Original data points: {summary['total_original_points']:,}")
    logger.info(f"Processed data points: {summary['total_processed_points']:,}")
    logger.info(f"Average compression ratio: {summary['average_compression_ratio']:.4f}")
    logger.info(f"Data reduction: {summary['data_reduction']:.2%}")
    
    # 실패한 파일들 출력
    if failed:
        logger.warning(f"\nFailed files ({len(failed)}):")
        for f in failed[:10]:  # 최대 10개만 출력
            logger.warning(f"  {f['mmsi']}: {f.get('error', 'Unknown error')}")
        if len(failed) > 10:
            logger.warning(f"  ... and {len(failed) - 10} more")
    
    return summary


def main():
    """메인 실행 함수"""
    parser = argparse.ArgumentParser(description='MMSI Trajectory Data Preprocessing')
    parser.add_argument('--input_dir', type=str, default='mmsi_tracks/mmsi_tracks',
                       help='Input directory containing MMSI CSV files')
    parser.add_argument('--output_dir', type=str, default='mmsi_tracks/processed_mmsi_tracks',
                       help='Output directory for processed files')
    parser.add_argument('--strategy', type=str, default='daily_avg',
                       choices=['daily_avg', 'hourly_avg', 'random'],
                       help='Sampling strategy')
    parser.add_argument('--processes', type=int, default=None,
                       help='Number of processes (default: CPU count)')
    parser.add_argument('--max_files', type=int, default=None,
                       help='Maximum number of files to process (for testing)')
    parser.add_argument('--test_mode', action='store_true',
                       help='Test mode: process only 5 files')
    
    args = parser.parse_args()
    
    # 경로 설정
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    
    if not input_dir.exists():
        logger.error(f"Input directory does not exist: {input_dir}")
        return
    
    # 테스트 모드
    max_files = args.max_files
    if args.test_mode:
        max_files = 5
        logger.info("Running in test mode (5 files only)")
    
    # 시작 시간 기록
    start_time = datetime.now()
    logger.info(f"Starting MMSI data preprocessing at {start_time}")
    
    # 메인 처리
    summary = process_mmsi_data_parallel(
        tracks_dir=input_dir,
        output_dir=output_dir,
        sampling_strategy=args.strategy,
        num_processes=args.processes,
        max_files=max_files
    )
    
    # 종료 시간 및 소요 시간 계산
    end_time = datetime.now()
    elapsed_time = end_time - start_time
    
    logger.info("=" * 60)
    logger.info(f"Processing completed at {end_time}")
    logger.info(f"Total elapsed time: {elapsed_time}")
    logger.info(f"Processed files saved to: {output_dir}")
    
    # 성능 통계
    if summary['successful'] > 0:
        files_per_second = summary['successful'] / elapsed_time.total_seconds()
        logger.info(f"Processing speed: {files_per_second:.2f} files/second")


if __name__ == "__main__":
    main() 